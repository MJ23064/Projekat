package projekat;

public class Enemy extends GameObject {
	private String type;
	private int damage;
	private int health;
	
	public Enemy(int x, int y, int width, int height, String type, int damage, int health) {
		super(x, y, width, height);
		this.setType(type);
		this.setDamage(damage);
		this.setHealth(health);
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		if(type == null) {
			System.out.println("type igraca ne smije biti prazan");
		}else {
			this.type = type;
		}
	}
	

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		if(damage<=0 || damage>=100) {
			System.out.println("Damage je od 0 do 100");
		}else {
			this.damage = damage;
	}
		
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		if(health<=0 || health>=100) {
			System.out.println("Health bar je od 0 do 100");
		}else {
		this.health = health;
	}
		
    }

	@Override
	public String toString() {
		return "Enemy [" + type + "] @ (" + getX() + "," + getY() + ") " + getWidth() + "x"
				+ getHeight() + " DMG=" + damage  + " HP=" + health + ".";
	}
	public int attack() {
	    return getDamage();
	}


	
	

}
