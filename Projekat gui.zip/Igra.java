package projekat;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class Igra extends JFrame{
	JLabel l1,l2,l3,l4,l5;
	JTextField t1,t2,t3,t4;
    JComboBox<String> c1;
    JButton b1,b2;
    JPanel p1, p2;  
    JScrollPane scroll;
    JTextArea rezultat;
	
	public Igra() {
	super("Game setup");
	this.setSize(800,500);
	this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	this.setLocationRelativeTo(null);
	this.setLayout(new BorderLayout());
	
	l1 = new JLabel("Ime:");
	l2 = new JLabel("Health (0-100):");
	l3 = new JLabel("X pozicija:");
	l4 = new JLabel("Y pozicija:");
	l5 = new JLabel("Kolajder:");
	
	t1 = new JTextField(15);
	t2 = new JTextField(15);
	t3 = new JTextField(15);
	t4 = new JTextField(15);
	
	String[] oblici = {"Pravougaonik 40x24", "Kvadrat 32x32"};

	c1 = new JComboBox<>(oblici);
	
	b1 = new JButton("Pokreni igru");
	b2 = new JButton("Sacuvaj");
	
	p1 = new JPanel();
	p1.setLayout(new GridLayout(6, 2, 5, 5));
	p1.setBorder(BorderFactory.createTitledBorder("Igrac"));
	
	p1.add(l1);
	p1.add(t1);

	p1.add(l2);
	p1.add(t2);

	p1.add(l3);
	p1.add(t3);

	p1.add(l4);
	p1.add(t4);

	p1.add(l5);
	p1.add(c1);

	p1.add(b1);
	p1.add(b2);
	
	
	
	
	rezultat = new JTextArea();
	rezultat.setEditable(false);

	scroll = new JScrollPane(rezultat);

	p2 = new JPanel();
	p2.setLayout(new BorderLayout());
	p2.setBorder(BorderFactory.createTitledBorder("Rezultat"));

	p2.add(scroll, BorderLayout.CENTER);
	
	this.add(p1, BorderLayout.WEST);
	this.add(p2, BorderLayout.CENTER);
	
	obradiDugmad obradjivac = new obradiDugmad();
	b1.addActionListener(obradjivac);
	


	
	
	
		
		
	}

	
	public class obradiDugmad implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
        if(e.getSource() == b1) {
        	
            String name = t1.getText();
            int health = Integer.parseInt(t2.getText());
            int x = Integer.parseInt(t3.getText());
            int y = Integer.parseInt(t4.getText());

            int width;
            int height;

            if (c1.getSelectedIndex() == 0) {
                width = 40;
                height = 24;
            } else {
                width = 32;
                height = 32;
            }

            Player player = new Player(x, y, width,height, name, health);

            rezultat.setText(player.toString());
            
            ArrayList<Enemy> zlikovci = new ArrayList<>();
            ArrayList<String> dogadjaji = new ArrayList<>();
            
            zlikovci.add(new MaleeEnemy(13,36,2,13,"Goblin",10,90));

            zlikovci.add(new BossEnemy(34,22,22,10,"Boss Goblin",30,90));

            zlikovci.add(new MaleeEnemy(15,2,12,43,"Opaki Goblin",20,90));
            
            for (Enemy neprijatelj : zlikovci) {

                if (player.intersect(neprijatelj)) {

                    int damage = neprijatelj.attack();

                    player.decreaseHealth(damage);

                    dogadjaji.add(neprijatelj.getType() +" je napao igraca i oduzeo mu " + damage + " HP.");
                    
                    rezultat.setText("STATUS IGRACA:\n");
                    rezultat.append(player.toString() + "\n");
                    
                    rezultat.append("\nLOG DOGADJAJA:\n");

                    for (String d : dogadjaji) {
                        rezultat.append(d + "\n");
                    }
                    
                    
                    if (player.getHealth() > 0) {
                    	 JOptionPane.showMessageDialog(null,"Igrac"+ name + "je prezivio sa" + health + "HP","Kraj igre",JOptionPane.INFORMATION_MESSAGE);
                    	 } else {
                        	 JOptionPane.showMessageDialog(null,"Igrac"+ name +"je porazen ","Kraj igre",JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        	
        }
        if(e.getSource() == b2) {
        	
        }
        
   
		}

	}
	
	public static void main(String[] args) {
		Igra i = new Igra();
		i.setVisible(true);
	}

}
