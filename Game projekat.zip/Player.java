package projekat;

public class Player extends GameObject {
	private String name;
	private int health;
	
	public Player(int x, int y, int width, int height, String name, int health) {
		super(x, y, width, height);
		this.setName(name);
		this.setHealth(health);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		if(name == null) {
			System.out.println("Napisite ime");
		}else {
	    this.name = name;

      	}
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		if(health<=0 || health>=100) {
			System.out.println("Health bar je od 0 do 100");
		}else {
		this.health = health;
	}	
   }

	@Override
	public String toString() {
		return "Player [" + name + "]@ ( "+ getX() +"," +  getY()  + ")"
				+  getWidth() + "x" + getHeight() + "HP=" + getHealth() + ".";
	}
	public void decreaseHealth(int damage) {
	    health = health - damage;
	}
	
	

}
