package projekat;

public class MaleeEnemy extends Enemy {

	public MaleeEnemy(int x, int y, int width, int height, String type, int damage, int health) {
		super(x, y, width, height, type, damage, health);
	}
	public int attack() {
		int napad = getDamage();
		return napad;
	}
	
	
	
	

}
