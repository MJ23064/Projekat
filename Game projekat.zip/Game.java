package projekat;

import java.util.ArrayList;


public class Game {
    
	
	

	public static void main(String[] args) {
		
    Player p1 = new Player(12,2,32,23,"Petar Petrovic",94);
    Enemy e1 = new Enemy(13,36,2,13,"Goblin",10,90);
    Enemy e2 = new Enemy(34,22,22,10,"Boss Goblin",30,90);
    Enemy e3 = new Enemy(15,2,12,43,"opaki Goblin",20,90);
    ArrayList<Enemy>zlikovci = new ArrayList<>();
    zlikovci.add(e1);
    zlikovci.add(e2);
    zlikovci.add(e3);
    ArrayList<String>dogadjaji = new ArrayList<>();
    for(Enemy e:zlikovci) {
    System.out.println(e);
    }
    for (Enemy e : zlikovci) {
    	p1.decreaseHealth(e.getDamage());
    	dogadjaji.add(e.getType() + " je napao igraca i oduzeo mu je:"+ e.getDamage() + " health-a.");
    	System.out.println(p1);
        System.out.println(e);
        
    }
    

    
   

 
    for (Enemy e : zlikovci) {
        if (p1.intersect(e)) {
            p1.decreaseHealth(e.getDamage());
            dogadjaji.add(e.getType() + " je sudario igraca");
        }
        for (String d : dogadjaji) {
            System.out.println(d);
        }
    
    
    }
	}
}

    
    	
    	
		
		

	


